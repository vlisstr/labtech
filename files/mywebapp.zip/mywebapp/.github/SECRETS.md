# GitHub repository configuration

After cloning the repository to your own GitHub account, you must configure
**secrets** and **branch protection** for the CI/CD pipeline to work end-to-end.

## Secrets

`Settings → Secrets and variables → Actions → New repository secret`

| Name | Value | Where it comes from |
|---|---|---|
| `TARGET_HOST`     | Public IP or hostname of the **target node** VM | From your VM provider |
| `TARGET_USER`     | SSH user on the target VM (e.g. `deploy`)       | The user created by `deploy/target-setup.sh` |
| `TARGET_SSH_KEY`  | Full contents of the **private** SSH key paired with the deploy user's `authorized_keys` | Generated on the runner VM with `ssh-keygen -t ed25519 -f ~/.ssh/deploy_key` |

`GITHUB_TOKEN` is provided automatically — no manual setup required for pushing to GHCR.

## Branch protection (required by the spec)

`Settings → Branches → Add rule`

Branch name pattern: `main`

Enable:
- **Require a pull request before merging**
- **Require status checks to pass before merging**
  - Required checks: `Lint`, `Test (Jest + coverage ≥ 40%)`
- **Require branches to be up to date before merging** (optional, but recommended)
- **Do not allow bypassing the above settings** (optional)

Result: PRs cannot be merged unless lint and tests pass.

## Self-hosted runner registration

The CD job (`deploy`, `verify`) runs on `runs-on: self-hosted`. Configure a
self-hosted runner from a separate VM. See `deploy/runner-setup.sh` for the
automated part of the setup; the registration step itself (which involves a
short-lived token) is manual on purpose — never commit registration tokens.
