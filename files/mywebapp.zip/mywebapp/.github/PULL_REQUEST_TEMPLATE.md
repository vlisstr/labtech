<!-- A pull request to the main branch triggers Lint and Test checks; both
must pass before the PR can be merged. -->

## Summary

Briefly describe what this PR changes and why.

## Checklist

- [ ] Lint passes (`npm run lint` in `app/`)
- [ ] Tests pass with coverage ≥ 40% (`npm test` in `app/`)
- [ ] Updated documentation if behaviour changed
